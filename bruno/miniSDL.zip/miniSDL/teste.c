#include<SDL2/SDL.h>
#include<assert.h>

/* Window title */
#define WINDOW_TITLE "SDL2 Test"

int main( int argc, char* args[] ){

    int i;
    SDL_Init(SDL_INIT_VIDEO);

    SDL_DisplayMode vmode;
    SDL_GetDisplayMode(0, 0, &vmode);
    SDL_Window *win1 = NULL;
    win1 = SDL_CreateWindow("", 0, 0, vmode.w, vmode.h, SDL_WINDOW_SHOWN);

    SDL_Renderer* ren1 = NULL;
    ren1 =Â  SDL_CreateRenderer( win1, 0, SDL_RENDERER_ACCELERATED);
    SDL_SetRenderDrawColor( ren1, 0, 0, 0, 255 );  //set render to black for background
    SDL_RenderClear( ren1 );Â  Â Â  Â Â  Â Â  Â // Clear window


    SDL_SetRenderDrawColor( ren1, 0, 255, 0, 255 );  //Â  green rectangles
    for (int i=0; i<5; i++)
    {
        SDL_Rect* rect[i];

        rect[i].x = i*34;
        rect[i].y = 0;
        rect[i].w = 32;
        rect[i].h = 32;

        SDL_RenderDrawRect(ren1, &rect[i]);


        SDL_RenderFillRect(ren1, &rect[i]);
    }
    SDL_RenderPresent(ren1);
    SDL_Delay(5000);

    SDL_DestroyWindow(win1);
    SDL_DestroyRenderer(ren1);
SDL_Quit();
return 0;
} 
